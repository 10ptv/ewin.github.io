<?php

/**
 * Plugin Name: My Package
 * Plugin URI: https://example.com/my-package
 * Description: A description of your package.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: my-package
 * Domain Path: /languages
 */

// Add your package code here