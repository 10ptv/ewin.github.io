<?php
/*
Plugin Name: Simply Static Auto Generate
Plugin URI: https://codewp.ai
Description: Automatically generates a static website using Simply Static.
Author: CodeWP Assistant
Author URI: https://codewp.ai
Version: 1.0
License: GPL2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

add_action('wp_enqueue_scripts', 'simply_static_auto_generate_enqueue_scripts');
function simply_static_auto_generate_enqueue_scripts() {
    wp_enqueue_script('simply-static-auto-generate', plugin_dir_url(__FILE__) . 'js/simply-static-auto-generate.js', array('jquery'), '1.0', true);
    wp_localize_script('simply-static-auto-generate', 'simplyStatic', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
    ));
}

add_action('wp_ajax_simply_static_generate_website', 'simply_static_generate_website');
function simply_static_generate_website() {
    // Generate the static website here
    // ...

    // Return the response
    wp_send_json_success('Static website generated successfully.');
}